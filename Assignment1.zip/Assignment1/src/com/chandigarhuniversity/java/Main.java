package com.chandigarhuniversity.java;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
	Scanner scanner= new Scanner(System.in);
	System.out.println("Enter your name");
	String name=scanner.next();
        System.out.println("Enter your age");
    int age=scanner.nextInt();
        System.out.println("Enter your Blood group");
    String Blood_group=scanner.next();
    String message = null;
    if(age>=20)
    {
        message="Your Group is Red";
    }
    else if(age>=15 && age<20)
    {
        message="Your Group is Blue";
    }
    else if(age>=10 && age<15)
    {
        message="Your Group is Yellow";
    }
    System.out.println("Name:" +name);
        System.out.println("Age:" +age);
        System.out.println("Blood Group:" +Blood_group);
        System.out.println("-----------------------------------");
        System.out.println(message);
    }
}
